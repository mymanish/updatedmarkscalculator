// This file contains a list of proxies that can be used to fetch your response sheet
proxies = [
    "https://corsproxy2.vercel.app",
    "https://corsproxy-worker.timepassuser.workers.dev"
]